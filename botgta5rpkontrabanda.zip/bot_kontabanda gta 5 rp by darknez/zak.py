import pyautogui as pag
import keyboard as keyb
from keybind import KeyBinder
import time
from ahk import AHK
from tkinter import *
import pygame
import customtkinter
from PIL import ImageTk, Image 
from pynput import keyboard



pygame.mixer.init()
pygame.mixer.music.load("startsound.mp3")
pygame.mixer.music.play()

instr = customtkinter.CTk()  #creating cutstom tkinter window
instr.geometry("753x365")
instr.title('GTA 5 RP: КБ Инструкция')
instr.wm_geometry("+%d+%d" % (600, 200))
instr.resizable(False, False)

img1=ImageTk.PhotoImage(Image.open("im3.png"))

il=customtkinter.CTkLabel(master=instr, image=img1, text="")
il.pack()

ibutton2 = customtkinter.CTkButton(master=instr, width=515, height=40, text="Закрыть окно", font=('VK Sans Display Regular',16), command=instr.destroy, corner_radius=6)
ibutton2.place(x=127, y=300)

instr.after(30000, instr.destroy)
instr.mainloop()

pygame.mixer.init()
pygame.mixer.music.load("startsound.mp3")
pygame.mixer.music.play()