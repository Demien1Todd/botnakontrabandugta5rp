from tkinter import *
import tkinter.ttk as ttk
import time, threading


root = Tk()


root.attributes("-topmost",True)
x = (root.winfo_screenwidth() - root.winfo_reqwidth()) / 2
y = (root.winfo_screenheight() - root.winfo_reqheight()) / 2
root.wm_geometry("+%d+%d" % (640, 190))
root.resizable(False, False)
root.title("Time to next buy: 4 minutes")
icon = PhotoImage(file = "icon2.png")
root.iconphoto(False, icon)
root.geometry("650x30")
pb = ttk.Progressbar(root, mode="determinate")
pb.pack(fill=X, padx=6, pady=6)
pb.pack()
pb.start(2400) # запускаем progressbar
threading.Thread(target=pb.start).start()
root.after(240000, root.destroy)
root.mainloop()


