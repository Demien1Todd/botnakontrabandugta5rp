import pyautogui as pag
import keyboard as keyb
from keybind import KeyBinder
import time
from ahk import AHK
import mouse
from tkinter import *
import pygame
from tkinter import font
import tkinter
import customtkinter
from PIL import ImageTk, Image 
from pynput import keyboard
from threading import Thread


def instruction():
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    instr = customtkinter.CTk()  #creating cutstom tkinter window
    instr.geometry("753x502")
    instr.title('GTA 5 RP: КБ Инструкция')
    instr.wm_geometry("+%d+%d" % (600, 200))
    instr.resizable(False, False)
    img1=ImageTk.PhotoImage(Image.open("im2.png"))
    il=customtkinter.CTkLabel(master=instr, image=img1, text="")
    il.pack()
    ibutton2 = customtkinter.CTkButton(master=instr, width=515, height=40, text="Закрыть окно", font=('VK Sans Display Regular',16), command=instr.destroy, corner_radius=6)
    ibutton2.place(x=127, y=440)
    instr.mainloop()
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()


customtkinter.set_appearance_mode("System")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("green")  # Themes: blue (default), dark-blue, green
pygame.mixer.init()
pygame.mixer.music.load("startsound.mp3")
pygame.mixer.music.play()
avtorizacia = customtkinter.CTk()  #creating cutstom tkinter window
avtorizacia.geometry("753x502")
avtorizacia.title('GTA 5 RP: КБ')
x = (avtorizacia.winfo_screenwidth() - avtorizacia.winfo_reqwidth()) / 2
y = (avtorizacia.winfo_screenheight() - avtorizacia.winfo_reqheight()) / 2
avtorizacia.wm_geometry("+%d+%d" % (600, 200))
avtorizacia.resizable(False, False)
imga=ImageTk.PhotoImage(Image.open("im1.png"))
al=customtkinter.CTkLabel(master=avtorizacia, image=imga, text="")
al.pack()
avtorizaciabutton = customtkinter.CTkButton(master=avtorizacia, width=345, height=40, text="Инструкция", font=('VK Sans Display Regular',16), command=instruction, corner_radius=6)
avtorizaciabutton.place(x=320, y=440)
avtorizaciabutton2 = customtkinter.CTkButton(master=avtorizacia, width=210, height=40, text="Закрыть окно", font=('VK Sans Display Regular',16), command=avtorizacia.destroy, corner_radius=6)
avtorizaciabutton2.place(x=100, y=440)
avtorizacia.mainloop()
pygame.mixer.init()
pygame.mixer.music.load("startsound.mp3")
pygame.mixer.music.play()


def zak():
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()

    instr2 = customtkinter.CTk()  #creating cutstom tkinter window
    instr2.geometry("753x365")
    instr2.title('GTA 5 RP: КБ')
    instr2.wm_geometry("+%d+%d" % (600, 200))
    instr2.resizable(False, False)

    img12=ImageTk.PhotoImage(Image.open("im3.png"))

    il2=customtkinter.CTkLabel(master=instr2, image=img12, text="")
    il2.pack()

    ibutton22 = customtkinter.CTkButton(master=instr2, width=515, height=40, text="Закрыть окно", font=('VK Sans Display Regular',16), command=instr2.destroy, corner_radius=6)
    ibutton22.place(x=127, y=300)

    instr2.after(30000, instr2.destroy)
    instr2.mainloop()

    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()



def on_triggered():
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    time.sleep(0.2)
    keyb.press('e') #1-й цикл
    time.sleep(0.5)
    keyb.release('e')
    pag.moveTo(729, 870)
    pag.click()
    time.sleep(0.3)
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    exec(open("progressbar.py").read())
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    time.sleep(1.6)
    keyb.press('e') #2-й цикл
    time.sleep(0.5)
    keyb.release('e')
    pag.moveTo(729, 870)
    pag.click()
    time.sleep(0.3)
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    exec(open("progressbar.py").read())
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    time.sleep(1.6)
    keyb.press('e') #3-й цикл
    time.sleep(0.5)
    keyb.release('e')
    pag.moveTo(729, 870)
    pag.click()
    time.sleep(0.3)
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    exec(open("progressbar.py").read())
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    time.sleep(1.6)
    keyb.press('e') #3-й цикл
    time.sleep(0.5)
    keyb.release('e')
    pag.moveTo(729, 870)
    pag.click()
    time.sleep(0.3)
    keyb.press('s')
    time.sleep(0.2)
    keyb.release('s')
    time.sleep(1.6)
    keyb.press('c')
    time.sleep(0.4)
    keyb.release('c')
    time.sleep(0.5)
    keyb.press('shift+w')
    time.sleep(2)
    keyb.release('shift+w')
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    exec(open("progressbar.py").read())
    pygame.mixer.init()
    pygame.mixer.music.load("releasesond.mp3")
    pygame.mixer.music.play()
    keyb.press('i')
    time.sleep(0.2)
    keyb.release('i')
    zak()



def on_save():
    pygame.mixer.init()
    pygame.mixer.music.load("startsound.mp3")
    pygame.mixer.music.play()
    keyb.press('ctrl+b')  
    time.sleep(0.1)
    keyb.release('ctrl+b')
    pag.click(430, 410, 2, 0.1, 'right')
    pag.click(520, 410, 2, 0.01, 'right')
    pag.click(610, 410, 2, 0.01, 'right')
    pag.click(704, 410, 2, 0.01, 'right')
    keyb.press('esc') 
    time.sleep(0.1)
    keyb.release('esc')



keyb.add_hotkey('tab+p', on_triggered)
keyb.add_hotkey('tab+s', on_save)   
